<?php

use Elementor\Controls_Manager;
use ElementorPro\Modules\DynamicTags\Tags\Base\Tag;
use ElementorPro\Modules\DynamicTags\Module;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class Elementor_Post_Video extends \Elementor\Core\DynamicTags\Tag {

	public function get_name() {
		return 'post-video';
	}

	public function get_title() {
		return __( 'Post Video', 'moomoo-extensions-elementor' );
	}
	public function get_icon() {
		return 'eicon-youtube';
	}

	/*public function get_group() {
		return Module::POST_GROUP;
	}*/
	public function get_group() {
		return 'request-variables';
	}

	public function get_categories() {
		return [ Module::TEXT_CATEGORY ];
	}

	public function render() {
		echo wp_kses_post( get_the_title() );
	}
}
