 === Moomoo Extensions Elementor ===
Contributors: Ngadt
Tags: elementor extensions
Tested up to: 7.7.1
Stable tag: 3.0.1
License: GPLv2 or later

The Categories Moomoo Extensions Elementor extend some function for Elementor: posts layout, gravityform style, sliders, buttons, media ...

=== Version: 1.2.4 ===
- Add function auto upgrade plugin