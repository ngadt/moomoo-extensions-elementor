 === Moomoo Extensions Elementor ===
Contributors: Ngadt
Tags: elementor extensions
Tested up to: 7.7.1
Stable tag: 3.0.1
License: GPLv2 or later

The Categories Moomoo Extensions Elementor extend some function for Elementor: posts layout, gravityform style, sliders, buttons, media ...

=== Version: 1.2.4 ===
- Add function auto upgrade plugin

=== Version: 1.2.5 ===
- Fix bug can not load element editor when active plugin
- Fix and add new function border style for input in GF

=== Version: 1.2.6 ===
- Update to compatie with elementor ver 3.6.0
- Update style for Gravity Form

=== Version: 1.2.7 ===
- Update to compatie with elementor ver 3.6.0
- Add new future style for Gravity Form: (button next, prev, mobile responsive)

=== Version: 1.2.8 ===
- fix bug GF: left, right, input
- add future Moomoo Button: Button padding
- remove outline button
- full width msm erro
- breakpoint responsive
